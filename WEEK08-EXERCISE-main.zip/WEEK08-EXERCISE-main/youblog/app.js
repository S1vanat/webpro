
const article= require('./article-db.json')
const express = require('express')
// อิมพอตเอ้กเพรสที่ดาวโหลดไว้ในตัวแปร express
const path = require('path')

const app = express()
// เรียกใช้งานผ่านฟังชัน

// Setup ejs เพื่อให้ app.js สามารถใช้งานร่วใกับ ejs ได้
app.set('view engine', 'ejs');
// app จะเซ็ต view engine ให้รัน ejs 
app.set('views', path.join(__dirname, 'views'));
// app นำ component จาก folder views มาใช้ในการแสดงผล

// Setup static path เซ็ต folder ที่จะนำมาใช้ในการ render สวนของ static ต่างๆ
app.use(express.static(path.join(__dirname, 'public')))

app.get('/blogapi', (req, res) =>{
    res.json(article)
})
app.get('/blogapi/:id', (req, res) =>{
    res.json(article.find(article => article.id === req.params.id))
})

// Config Router กำหนด router ที่จะใช้กับ app.js
const indexRouter = require('./routes/index')
const blogRouter = require('./routes/blog')
// .use จะเป้นการบอกให้ app.js ทำการ use ตัว router จาก index router
// เพื่อแยกทุกอย่างให้เป้นสัดส่วนมากขึ้น
app.use('/', indexRouter)
app.use('/blog', blogRouter)

// app.get("/", (req, res) =>{
//     res.send("Test")
// })
// ฟังชัน get มีพารามีเต้อ 2 ตัว
// 1 (Path) / กำหนดpathให้ user รู้ว่าเรียกใช้ไปยังrouter ว่าต้องใช้ path ไหน
// 2 (function) มี 2 พารามีเต้อ req res เมื่อผู้ใช้มีการเรียก req ตามพาทที่เรากำหนดไว้
// ตัว router ก็จะทำงานตามฟังชันที่เรากำหนดไว้ในพาทนั้นๆ

// res.send จะมีการดึงค่า http response ออกไป เมื่อเราเปิดเว็บก้จะเห็นข้อความ

app.listen(3000, () =>{
    console.log("Start servar at port 3000")
})
// listen มีพารามิเตอ 2 ตัว
// 1 พอต number เป็นการกำหนดให้ผู้ใช้รู้ว่าต้องใช้ตัวไหน
// 2 ฟังชัน เมื่อมีการเริ่มเซิฟเว่อนี้ จะมีการทำอะไรเกิดขึ้น

// ติดตั้ง nodemon เพราะ เพื่อให้ server อัพเดทตลอด ไม่ต้องคอยใช้คำสั่ง node