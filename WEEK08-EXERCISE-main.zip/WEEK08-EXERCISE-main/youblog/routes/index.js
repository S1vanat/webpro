const express = require('express')
const router = express.Router()
// อิมพอตมาใช้งาน อิมพอต express ออกมาก่อน แล้วนำ express.js มาแยกเฉพาะ
// ตัว fn router ออกมาใช้แล้วเก็บไว้ในตัวแปร router จากนั้นนำตัวแปร router 
// มาใช้ในการ set ค่า path เพื่อใช้เป้นพาทให้ไฟล์อื่นสามารถเรียกใช้ router ได้ 
const article = require("../article-db.json")

router.get('/', function(req, res, next) {
    if(req.query.search == "" || req.query.search == null){
        var searchData = article;
    }else{
        var searchValue = req.query.search;
        var searchData = [];
        article.map((val) =>{
            if(val.title.toLowerCase().includes(searchValue.toLowerCase())){
                searchData.push(val)
            }
        })
    }

    var data = {title: 'You Blog', article: searchData}
    res.render('index', data)

})
// เป้นการใช้พาท default
// ทำการเซตดาต้ามีไตเติ้ลคือเอ้กเพรสมีอาติเคิ้ลทั้งก้อนโยนเข้าดาต้าเข้าไปด้วย

// router.get('/', function(req, res, next) {
//     var data = { title: 'Express' }
//     res.render('index', data)
// })
// ในฟังชันมีการรีเควส ตัว router จะมีการเซตดาต้า มีลักษณะเป้น object
// มีคีย์เป้น title มีค่าเป้น express จากนั้น router จะ render file index
// จากนั้น ทำการเซตค่าตัวดาต้าไปด้วยเวลา render เพื่อให้ index สามารถใชังานดาต้าได้
module.exports = router
// เพื่อให้ไฟล์อื่นเรียกใช้งาน router ตัวนี้ได้